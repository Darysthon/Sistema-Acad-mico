#include <iostream>
#include <string>
using namespace std;

struct Aluno {
  string nome;
  int matricula;
  float cra;
};

struct Disciplina {
  string nome;
  string professorResponsavel;
  int codigo;
};

const Aluno alunoFim = {"", 0, 0};
const Disciplina disciplinaFim = {"", "", 0};

void cadastrarAlunos(Aluno alunos[]) {
    int i = 0;
    char continuar;

    do {
        cout << "Digite o nome do aluno(a): ";
        cin >> alunos[i].nome;
        if (alunos[i].nome.empty()) 
            break;

        cout << "Digite a matricula do aluno(a): ";
        cin >> alunos[i].matricula;

        i++;

        cout << "Deseja adicionar outro aluno? (s/n): ";
        cin >> continuar;
    } while (continuar == 's' || continuar == 'S');

    alunos[i] = alunoFim;
}

void cadastrarDisciplina (Disciplina disciplinas[], int &quantidadeDisciplinas) {
    cout << "Digite o nome da disciplina: ";
    cin >> disciplinas[quantidadeDisciplinas].nome;
    if (disciplinas[quantidadeDisciplinas].nome.empty()) 
        return;

    cout << "Digite o nome do professor responsavel: ";
    cin >> disciplinas[quantidadeDisciplinas].professorResponsavel;

    cout << "Digite o codigo da disciplina: ";
    cin >> disciplinas[quantidadeDisciplinas].codigo;

    quantidadeDisciplinas++;
}

void exibirAlunos(Aluno alunos[]) {
    int i = 0;
    while (alunos[i].nome != "") {
        cout << "Nome:" << alunos[i].nome << endl;
        cout << "Matricula:" << alunos[i].matricula << endl;
        i++;
    }
}

void exibirDisciplinas(Disciplina disciplinas[]) {
  int i = 0;
  while (disciplinas[i].nome != "") {
    cout << "Nome da disciplina: " << disciplinas[i].nome << endl;
    cout << "Professor responsavel: " << disciplinas[i].professorResponsavel << endl;
    cout << "Codigo da disciplina: " << disciplinas[i].codigo << endl;
    i++;
  }
}

void adicionarAlunoDisciplina (

void exibirMenu () {
  cout << "--------------------------------------" << endl;
  cout << "        SISTEMA ACADÊMICO            " << endl;
  cout << "--------------------------------------" << endl << endl;

  cout << "1. Cadastrar aluno" << endl;
  cout << "2. Cadastrar disciplina" << endl;
  cout << "3. Adicionar Aluno em disciplina" << endl;
  cout << "4. Registrar notas" << endl;
  cout << "5. Verificar disciplinas" << endl;
  cout << "6. Verificar alunos matriculados" << endl;
  cout << "7. Sair" << endl << endl;
  

  cout << "--------------------------------------" << endl;
}

int main() {

  Aluno alunos[100];
  Disciplina disciplinas[100];
  int quantidadeDisciplinas = 0;

  int opcao;

  do {
    exibirMenu(); 
    cout << "Digite a opcao desejada: ";
    cin >> opcao;

    switch (opcao) {
      case 1:
        cadastrarAlunos(alunos);
        break;

      case 2:
        cadastrarDisciplina(disciplinas, quantidadeDisciplinas);
        break;

      case 3:
        
        break;

      case 4:

        break;

      case 5:
        exibirDisciplinas(disciplinas);
        break;

      case 6:
        exibirAlunos(alunos);
        break;

      case 7:
        cout << "Encerrando o sistema." << endl;
        return 0;

      default:
        cout << "Opção inválida!" << endl;
    }
  } while (opcao != 7);

  return 0;
}
  

